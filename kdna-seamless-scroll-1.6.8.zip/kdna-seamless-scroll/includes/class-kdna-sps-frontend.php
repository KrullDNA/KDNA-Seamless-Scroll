<?php
// Stop anyone loading this file directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles everything on the front end: deciding when to run, loading the
 * script and stylesheet, building the loader styling from the saved settings,
 * and passing those settings through to the JavaScript.
 */
class KDNA_SPS_Frontend {

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		// Transition CSS goes high in the head; the colour cover (if used) is
		// printed right after <body> so it paints with the very first frame.
		add_action( 'wp_head', array( $this, 'render_transition_head' ), 1 );
		add_action( 'wp_body_open', array( $this, 'render_cover' ) );
	}

	/**
	 * The chosen transition mode: 'crossfade' (no colour — pages cross-dissolve
	 * via the View Transitions API), 'cover' (fade through a colour) or 'none'.
	 */
	private function get_transition_mode() {
		$opts = kdna_sps_get_options();
		$mode = isset( $opts['transition_mode'] ) ? $opts['transition_mode'] : 'crossfade';
		if ( ! in_array( $mode, array( 'crossfade', 'cover', 'none' ), true ) ) {
			$mode = 'crossfade';
		}
		return $mode;
	}

	/**
	 * Inline transition CSS in the head. For crossfade this opts the page into
	 * cross-document View Transitions so the browser dissolves between projects
	 * with no colour. For cover it styles an opaque overlay that fades out on
	 * load (via a keyframe, so content is never trapped even if JS fails).
	 */
	public function render_transition_head() {
		if ( ! $this->is_target_page() ) {
			return;
		}
		$mode = $this->get_transition_mode();
		if ( 'none' === $mode ) {
			return;
		}
		$opts = kdna_sps_get_options();
		$ms   = absint( $opts['transition_ms'] );
		if ( ! $ms ) {
			$ms = 300;
		}

		if ( 'crossfade' === $mode ) {
			// Hold the outgoing page fully opaque underneath and fade the incoming
			// page in on top, so the combined image never drops below 100% opacity.
			// That removes the split-second white flicker the default cross-fade
			// shows (where both pages are half-transparent and the backdrop peeks
			// through), while still dissolving seamlessly when the images match.
			echo '<style id="kdna-sps-vt-css">'
				. '@view-transition{navigation:auto;}'
				. '::view-transition-old(root){animation:none;mix-blend-mode:normal;}'
				. '::view-transition-new(root){animation:kdnaSpsVtIn ' . $ms . 'ms ease both;mix-blend-mode:normal;}'
				. '@keyframes kdnaSpsVtIn{from{opacity:0}to{opacity:1}}'
				. $this->persistent_elements_css()
				. '</style>';
			return;
		}

		// Colour cover.
		$colour = sanitize_hex_color( $opts['transition_colour'] );
		if ( ! $colour ) {
			$colour = '#ffffff';
		}
		echo '<style id="kdna-sps-cover-css">'
			. '.kdna-sps-cover{position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483600;'
			. 'background:' . $colour . ';opacity:1;pointer-events:none;will-change:opacity;'
			. 'animation:kdnaSpsCoverOut ' . $ms . 'ms ease forwards;}'
			. '@keyframes kdnaSpsCoverOut{from{opacity:1}to{opacity:0}}'
			. '</style>';
	}

	/**
	 * The colour-cover element, printed as the first thing inside <body>. Only
	 * used in 'cover' mode; crossfade and none need no element.
	 */
	public function render_cover() {
		if ( ! $this->is_target_page() ) {
			return;
		}
		if ( 'cover' !== $this->get_transition_mode() ) {
			return;
		}
		echo '<div class="kdna-sps-cover" aria-hidden="true"></div>';
	}

	/**
	 * The persistent-element pins as a list of [ 'sel' => selector, 'name' =>
	 * view-transition-name ] pairs, built from the saved selectors (one per line).
	 * Shared by the baseline CSS and the JS that de-duplicates sticky-header clones.
	 */
	private function get_pins() {
		$opts = kdna_sps_get_options();
		$raw  = isset( $opts['persistent_selectors'] ) ? (string) $opts['persistent_selectors'] : '';
		$pins = array();
		$i    = 0;
		foreach ( preg_split( '/[\r\n]+/', $raw ) as $line ) {
			$selector = $this->sanitise_css_selector( $line );
			if ( '' === $selector ) {
				continue;
			}
			$i++;
			$pins[] = array(
				'sel'  => $selector,
				'name' => 'kdna-vt-' . $i,
			);
		}
		return $pins;
	}

	/**
	 * Baseline CSS that pins persistent elements (typically the header/logo)
	 * during the crossfade. A stable view-transition-name tells the browser the
	 * element is the SAME on both pages, so it holds in place instead of being
	 * caught in the dissolve — which stops the logo flicker.
	 *
	 * This alone breaks when Elementor's sticky effect clones the header (the name
	 * then matches two elements and the browser voids it), so the script in
	 * kdna-seamless-scroll.js re-applies the name to only the live element right
	 * before each page snapshot. The CSS still covers the fresh, un-cloned page.
	 */
	private function persistent_elements_css() {
		$css = '';
		foreach ( $this->get_pins() as $pin ) {
			$css .= $pin['sel'] . '{view-transition-name:' . $pin['name'] . ';}';
		}
		return $css;
	}

	/**
	 * Keep only characters that are valid in a CSS selector, so a setting can
	 * never break out of the inline <style> or inject extra rules.
	 */
	private function sanitise_css_selector( $selector ) {
		$selector = trim( (string) $selector );
		// Strip anything outside a conservative selector allow-list (notably no
		// <, {, }, ; or @, which could escape the style block).
		$selector = preg_replace( '/[^a-zA-Z0-9 .#:_\-\[\]=\"\'()>~+*^$|]/', '', $selector );
		return trim( $selector );
	}

	/**
	 * Which post type(s) the seamless scroll runs on, taken from the settings
	 * and still filterable for anyone who prefers code.
	 */
	private function get_post_types() {
		$opts  = kdna_sps_get_options();
		$types = array_filter( array_map( 'trim', explode( ',', (string) $opts['post_types'] ) ) );
		if ( empty( $types ) ) {
			$types = array( 'portfolio' );
		}
		return apply_filters( 'kdna_sps_post_types', $types );
	}

	/**
	 * Are we on a single page that should run the effect?
	 */
	private function is_target_page() {
		return is_singular( $this->get_post_types() );
	}

	/**
	 * The list of CSS selectors the script will try, in order, to find the
	 * content wrapper. A single selector set on the Settings page wins.
	 */
	private function get_content_selectors() {
		$opts = kdna_sps_get_options();
		if ( ! empty( $opts['content_selector'] ) ) {
			$selectors = array( $opts['content_selector'] );
		} else {
			$selectors = array(
				'.elementor-location-single',
				'main .elementor',
				'main',
				'#content',
			);
		}
		return apply_filters( 'kdna_sps_content_selectors', $selectors );
	}

	/**
	 * Load the JS and CSS, but only on the target single pages, never site wide.
	 */
	public function enqueue_assets() {

		if ( ! $this->is_target_page() ) {
			return;
		}

		$opts = kdna_sps_get_options();

		// Stylesheet for the loading indicator and panel layout.
		wp_enqueue_style(
			'kdna-sps',
			KDNA_SPS_URL . 'assets/css/kdna-seamless-scroll.css',
			array(),
			KDNA_SPS_VERSION
		);

		// Loader colours and size come from the settings, applied as CSS variables.
		wp_add_inline_style( 'kdna-sps', $this->build_loader_css( $opts ) );

		// The engine itself. jQuery is listed so it loads after it, which the
		// Elementor re-init relies on.
		wp_enqueue_script(
			'kdna-sps',
			KDNA_SPS_URL . 'assets/js/kdna-seamless-scroll.js',
			array( 'jquery' ),
			KDNA_SPS_VERSION,
			true
		);

		// Pass the settings through to the JavaScript.
		wp_localize_script(
			'kdna-sps',
			'KDNA_SPS',
			array(
				'contentSelectors' => $this->get_content_selectors(),
				'nextLinkSelector' => apply_filters( 'kdna_sps_next_link_selector', (string) $opts['next_link_selector'] ),
				'preloadSelector'  => apply_filters( 'kdna_sps_preload_selector', (string) $opts['preload_selector'] ),
				'advanceSelector'  => apply_filters( 'kdna_sps_advance_selector', (string) $opts['advance_selector'] ),
				'postTypeSlug'     => apply_filters( 'kdna_sps_post_type_slug', current( $this->get_post_types() ) ),
				'triggerOffset'    => apply_filters( 'kdna_sps_trigger_offset', absint( $opts['trigger_offset'] ) ),
				'reinitAnimations' => ! empty( $opts['reinit_animations'] ),
				'reexecScripts'    => ! empty( $opts['reexec_scripts'] ),
				'transitionMode'   => $this->get_transition_mode(),
				'transitionMs'     => absint( $opts['transition_ms'] ),
				'pins'             => $this->get_pins(),
				'loader'           => array(
					'type'  => $opts['loader_type'],
					'image' => esc_url( $opts['loader_image'] ),
				),
				'debug'            => isset( $_GET['kdna_debug'] ),
				'homeUrl'          => home_url(),
			)
		);
	}

	/**
	 * Build the small block of CSS that themes the loader from the settings.
	 */
	private function build_loader_css( $opts ) {

		$spinner = sanitize_hex_color( $opts['spinner_colour'] );
		$bg      = sanitize_hex_color( $opts['loader_bg_colour'] );
		$size    = absint( $opts['loader_size'] );

		if ( empty( $spinner ) ) {
			$spinner = '#ffffff';
		}
		if ( empty( $bg ) ) {
			$bg = '#141a26';
		}
		if ( empty( $size ) ) {
			$size = 20;
		}

		// The faint ring is the icon colour at roughly 30 per cent opacity (8 digit hex).
		$track = $spinner . '4d';

		$css  = ':root{';
		$css .= '--kdna-sps-spinner-colour:' . $spinner . ';';
		$css .= '--kdna-sps-spinner-track:' . $track . ';';
		$css .= '--kdna-sps-bg:' . $bg . ';';
		$css .= '--kdna-sps-size:' . $size . 'px;';
		$css .= '}';

		// Hide the pill if the background has been switched off.
		if ( empty( $opts['loader_bg_enabled'] ) ) {
			$css .= '.kdna-sps-loader::before{display:none;}';
		}

		return $css;
	}
}
